from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Списки слов по темам (по 10 слов, все 5-буквенные)
word_lists = {
    "Animals": ["tiger", "eagle", "horse", "shark", "zebra", "panda", "snake", "whale", "sheep", "llama"],
    "Professions": ["pilot", "nurse", "actor", "baker", "guard", "miner", "clerk", "judge", "coach", "chief"],
    "Space": ["earth", "orbit", "comet", "alien", "venus", "solar", "lunar", "black", "nebul", "pluto"],
    "Music": ["piano", "opera", "flute", "guitar", "viola", "banjo", "synth", "choir", "drums", "harps"],
    "Sports": ["tenis", "rugby", "karat", "fence", "chess", "skate", "javel", "swimm", "cycle", "golf"],
    "Technology": ["robot", "laser", "modem", "fiber", "touch", "pixel", "drone", "cloud", "bytes", "radio"],
    "Mythology": ["zeus", "thor", "loki", "giant", "nymph", "hydra", "medus", "cerbe", "odin", "griff"],
    "Weather": ["storm", "cloud", "sunny", "frost", "breeze", "rainy", "humid", "torny", "sleet", "blizz"],
    "Food": ["pizza", "berry", "apple", "bread", "sugar", "mango", "spice", "grape", "honey", "cream"],
    "Random": ["crown", "table", "money", "green", "waste", "brick", "watch", "spoon", "paint", "cable"]
}

current_word = ""

@app.route("/")
def index():
    return render_template("index.html", themes=list(word_lists.keys()))

@app.route("/start_game", methods=["POST"])
def start_game():
    global current_word
    data = request.json
    theme = data.get("theme", "Random")
    current_word = random.choice(word_lists[theme])
    return jsonify({"message": "Game started", "word_length": len(current_word)})

@app.route("/check_word", methods=["POST"])
def check_word():
    global current_word
    data = request.json
    user_word = data.get("word", "").lower()

    if len(user_word) != 5:
        return jsonify({"error": "The word must be 5 letters long."})

    result = []
    for i, letter in enumerate(user_word):
        if letter == current_word[i]:
            result.append("green")
        elif letter in current_word:
            result.append("yellow")
        else:
            result.append("gray")

    win = (user_word == current_word)
    return jsonify({"result": result, "win": win, "word": current_word if not win else None})

@app.route("/new_game", methods=["POST"])
def new_game():
    return jsonify({"message": "Choose a theme to start a new game"})

if __name__ == "__main__":
    app.run(debug=True)

